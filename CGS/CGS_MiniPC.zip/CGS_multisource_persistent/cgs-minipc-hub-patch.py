#!/usr/bin/env python3
"""Corrige les boutons du hub CGS pour le Mini PC Batocera 42.

Configuration Mini PC :
  A (2) = ouvrir Windows / TeknoParrot
  B (3) = quitter CGS
  X (5) = déconnecter le compte CGS

Le script ne dépend pas de startup() et peut être relancé sans dupliquer
la modification.
"""

from pathlib import Path
import py_compile
import shutil
import sys
import tempfile
import time

DEFAULT_TARGET = Path("/userdata/system/cgs/app/hub.py")
MARKER = "# CONTROLES BOUTONS MINIPC BATOCERA42 HUB"

OLD_BUTTONS = '''   elif e.type==pygame.JOYBUTTONDOWN:\n    if e.button in (0,2):launch=True\n    elif e.button in (1,6,7,8):running=False\n    elif e.button==3:disconnect();notice='Session déconnectée pour les deux systèmes.'\n'''

NEW_BUTTONS = '''   elif e.type==pygame.JOYBUTTONDOWN:\n    # CONTROLES BOUTONS MINIPC BATOCERA42 HUB\n    if e.button==2:launch=True\n    elif e.button==3:running=False\n    elif e.button==5:disconnect();notice='Session déconnectée pour les deux systèmes.'\n'''


def apply(target: Path) -> int:
    if not target.exists():
        print(f"ERREUR : hub CGS introuvable : {target}")
        return 2

    original = target.read_text(encoding="utf-8")

    # Idempotence + validation du mapping attendu.
    if MARKER in original:
        required = (
            "if e.button==2:launch=True",
            "elif e.button==3:running=False",
            "elif e.button==5:disconnect()",
        )
        if all(x in original for x in required):
            print("Patch Mini PC du hub déjà présent.")
            return 0
        print("INCOMPATIBLE : marqueur Mini PC présent mais mapping inattendu.")
        return 20

    if OLD_BUTTONS not in original:
        print("INCOMPATIBLE : bloc boutons du hub non reconnu.")
        print("Aucun fichier n'a été modifié.")
        return 21

    work = original.replace(OLD_BUTTONS, NEW_BUTTONS, 1)

    # Valide avant d'écrire le fichier réel.
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".py", delete=False) as f:
        f.write(work)
        tmp = Path(f.name)

    try:
        py_compile.compile(str(tmp), doraise=True)
    except Exception as e:
        tmp.unlink(missing_ok=True)
        print(f"ERREUR : hub patché invalide : {e}")
        return 30
    tmp.unlink(missing_ok=True)

    backup = target.with_name(target.name + f".before-minipc-hub-{int(time.time())}.bak")
    try:
        shutil.copy2(target, backup)
        target.write_text(work, encoding="utf-8")
        py_compile.compile(str(target), doraise=True)
    except Exception as e:
        if backup.exists():
            shutil.copy2(backup, target)
        print(f"ERREUR : installation du patch hub impossible : {e}")
        return 31

    print(f"OK : hub Mini PC corrigé. Sauvegarde : {backup}")
    return 0


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_TARGET
    raise SystemExit(apply(target))
