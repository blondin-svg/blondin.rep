#!/bin/bash
set -eu

CGS_MAIN="/userdata/system/cgs/app/clients/windows/__main__.py"
HUB="/userdata/system/cgs/app/hub.py"
WIN_CACHE="/userdata/system/cgs/app/clients/windows/cache"
TP_CACHE="/userdata/system/cgs/app/clients/teknoparrot/cache"
AUTH_DIR="/userdata/system/cgs/state/auth"
PATCH_DST="/userdata/system/cgs-multisource-patch.py"
HUB_PATCH_DST="/userdata/system/cgs-minipc-hub-patch.py"
HERE="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(dirname "$HERE")"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "========================================================="
echo " CGS multi-sources - Mini PC Batocera 42 (hub corrigé)"
echo "========================================================="
echo ""

for f in "$CGS_MAIN" "$HUB"; do
    if [ ! -f "$f" ]; then
        echo "ERREUR : fichier CGS introuvable : $f"
        exit 1
    fi
done

for f in "$HERE/cgs-multisource-patch.py" "$HERE/cgs-minipc-hub-patch.py" "$HERE/controller.json"; do
    if [ ! -f "$f" ]; then
        echo "ERREUR : fichier d'installation absent : $f"
        exit 1
    fi
done

echo "[1/7] Sauvegarde de l'installation CGS actuelle..."
cp -p "$CGS_MAIN" "$CGS_MAIN.before-minipc-install-$STAMP.bak"
cp -p "$HUB" "$HUB.before-minipc-install-$STAMP.bak"

echo "[2/7] Installation des patchs persistants..."
cp -p "$HERE/cgs-multisource-patch.py" "$PATCH_DST"
cp -p "$HERE/cgs-minipc-hub-patch.py" "$HUB_PATCH_DST"
chmod +x "$PATCH_DST" "$HUB_PATCH_DST"
python3 -m py_compile "$PATCH_DST" "$HUB_PATCH_DST"

echo "[3/7] Application du patch multi-sources au client Windows..."
if ! python3 "$PATCH_DST" "$CGS_MAIN"; then
    echo "ERREUR : patch multi-sources impossible."
    echo "Sauvegarde : $CGS_MAIN.before-minipc-install-$STAMP.bak"
    exit 1
fi

echo "[4/7] Correction des boutons du hub Mini PC..."
if ! python3 "$HUB_PATCH_DST" "$HUB"; then
    echo "ERREUR : correction du hub impossible."
    echo "Sauvegarde : $HUB.before-minipc-install-$STAMP.bak"
    exit 1
fi

echo "[5/7] Vérification Python..."
python3 -m py_compile "$CGS_MAIN" "$HUB"

echo "[6/7] Installation de la configuration manette Mini PC..."
mkdir -p "$WIN_CACHE" "$TP_CACHE"
cp -p "$HERE/controller.json" "$WIN_CACHE/controller.json"
cp -p "$HERE/controller.json" "$TP_CACHE/controller.json"
chmod 644 "$WIN_CACHE/controller.json" "$TP_CACHE/controller.json"
echo "  Windows     : $WIN_CACHE/controller.json"
echo "  TeknoParrot : $TP_CACHE/controller.json"

echo "[7/7] Restauration éventuelle du compte CGS..."
mkdir -p "$AUTH_DIR"
chmod 700 "$AUTH_DIR" 2>/dev/null || true

find_auth() {
    if [ -f "$HERE/auth.json" ]; then
        printf '%s' "$HERE/auth.json"
    elif [ -f "$PARENT/auth.json" ]; then
        printf '%s' "$PARENT/auth.json"
    fi
}

AUTH_SRC="$(find_auth || true)"
if [ -n "$AUTH_SRC" ]; then
    cp -p "$AUTH_SRC" "$AUTH_DIR/auth.json"
    chmod 600 "$AUTH_DIR/auth.json"
    # Copie de compatibilité pour les versions du client Windows qui lisent encore cache/auth.json.
    cp -p "$AUTH_SRC" "$WIN_CACHE/auth.json"
    chmod 600 "$WIN_CACHE/auth.json"
    echo "  OK : auth.json restauré depuis $AUTH_SRC"
else
    echo "  INFO : aucun auth.json fourni -> compte CGS actuel conservé"
fi

echo ""
echo "Installation terminée."
echo ""
echo "Mini PC / Batocera 42"
echo "Sources Windows : windows + windowsretro + hacks"
echo "Hub : A=ouvrir, B=quitter, X=déconnecter"
echo "Manette : A=2 B=3 X=5 Y=4 LB=6 RB=7 START=11"
echo "Configuration installée pour Windows + TeknoParrot."
echo ""
echo "Le patch multi-sources est persistant et réapplique également"
echo "le correctif A/B/X du hub après les mises à jour CGS compatibles."
echo "Après une réinstallation complète de CGS, relance cet installateur."
