#!/bin/bash
set -eu

CGS_MAIN="/userdata/system/cgs/app/clients/windows/__main__.py"
HUB="/userdata/system/cgs/app/hub.py"
CGS_CACHE="/userdata/system/cgs/app/clients/windows/cache"
TP_CACHE="/userdata/system/cgs/app/clients/teknoparrot/cache"
AUTH_DIR="/userdata/system/cgs/state/auth"
PATCH_DST="/userdata/system/cgs-multisource-patch.py"
HUB_PATCH_DST="/userdata/system/cgs-steamdeck-hub-patch.py"
BUTTON_PATCH_DST="/userdata/system/cgs-steamdeck-buttons-patch.py"
HERE="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(dirname "$HERE")"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "========================================================"
echo " CGS multi-sources + Steam Deck - version corrigée"
echo "========================================================"
echo ""

for f in "$CGS_MAIN" "$HUB"; do
    if [ ! -f "$f" ]; then
        echo "ERREUR : fichier CGS introuvable : $f"
        exit 1
    fi
done

for f in "$HERE/cgs-multisource-patch.py" "$HERE/cgs-steamdeck-hub-patch.py" "$HERE/cgs-steamdeck-buttons-patch.py"; do
    if [ ! -f "$f" ]; then
        echo "ERREUR : fichier de patch absent : $f"
        exit 1
    fi
done

echo "[1/7] Sauvegarde de l'installation CGS actuelle..."
cp -p "$CGS_MAIN" "$CGS_MAIN.before-local-patch-$STAMP.bak"
cp -p "$HUB" "$HUB.before-steamdeck-install-$STAMP.bak"

echo "[2/7] Installation des patchs persistants..."
cp -p "$HERE/cgs-multisource-patch.py" "$PATCH_DST"
cp -p "$HERE/cgs-steamdeck-hub-patch.py" "$HUB_PATCH_DST"
cp -p "$HERE/cgs-steamdeck-buttons-patch.py" "$BUTTON_PATCH_DST"
chmod +x "$PATCH_DST" "$HUB_PATCH_DST" "$BUTTON_PATCH_DST"
python3 -m py_compile "$PATCH_DST" "$HUB_PATCH_DST" "$BUTTON_PATCH_DST"

echo "[3/7] Application multi-sources + navigation Steam Deck au client Windows..."
if ! python3 "$PATCH_DST" "$CGS_MAIN"; then
    echo "ERREUR : patch du client Windows impossible."
    echo "Sauvegarde : $CGS_MAIN.before-local-patch-$STAMP.bak"
    exit 1
fi

echo "[4/7] Application croix + boutons Steam Deck au sélecteur Windows / TeknoParrot..."
if ! python3 "$HUB_PATCH_DST" "$HUB"; then
    echo "ERREUR : patch du hub impossible."
    echo "Sauvegarde : $HUB.before-steamdeck-install-$STAMP.bak"
    exit 1
fi

echo "[5/7] Alignement des actions des boutons dans le client Windows..."
if ! python3 "$BUTTON_PATCH_DST" "$CGS_MAIN"; then
    echo "ERREUR : correction des boutons impossible."
    exit 1
fi

echo "[6/7] Vérification Python..."
python3 -m py_compile "$CGS_MAIN" "$HUB"

echo "[7/7] Restauration éventuelle du compte et des manettes..."
mkdir -p "$CGS_CACHE" "$TP_CACHE" "$AUTH_DIR"
chmod 700 "$AUTH_DIR" 2>/dev/null || true

find_backup_file() {
    name="$1"
    if [ -f "$HERE/$name" ]; then
        printf '%s' "$HERE/$name"
    elif [ -f "$PARENT/$name" ]; then
        printf '%s' "$PARENT/$name"
    fi
}

AUTH_SRC="$(find_backup_file auth.json || true)"
if [ -n "$AUTH_SRC" ]; then
    cp -p "$AUTH_SRC" "$AUTH_DIR/auth.json"
    chmod 600 "$AUTH_DIR/auth.json"
    # Copie de compatibilité pour les versions du client qui lisent encore cache/auth.json.
    cp -p "$AUTH_SRC" "$CGS_CACHE/auth.json"
    chmod 600 "$CGS_CACHE/auth.json"
    echo "  OK : auth.json restauré depuis $AUTH_SRC"
    echo "       -> $AUTH_DIR/auth.json"
else
    echo "  INFO : auth.json non trouvé -> aucune restauration"
fi

CTRL_SRC="$(find_backup_file controller.json || true)"
if [ -n "$CTRL_SRC" ]; then
    cp -p "$CTRL_SRC" "$CGS_CACHE/controller.json"
    cp -p "$CTRL_SRC" "$TP_CACHE/controller.json"
    chmod 644 "$CGS_CACHE/controller.json" "$TP_CACHE/controller.json"
    echo "  OK : controller.json Steam Deck restauré depuis $CTRL_SRC"
    echo "       -> Windows    : $CGS_CACHE/controller.json"
    echo "       -> TeknoParrot: $TP_CACHE/controller.json"
else
    echo "  INFO : controller.json non trouvé -> aucune restauration"
fi

echo ""
echo "Installation terminée."
echo "Client Windows : $CGS_MAIN"
echo "Hub CGS        : $HUB"
echo "Multi-sources  : windows + windowsretro + hacks"
echo "Steam Deck     : croix/stick + boutons A/B/X/Y/LB/RB/START cohérents"
echo "Manette        : configuration préchargée pour Windows + TeknoParrot"
echo ""
echo "Correction importante : la lecture evdev ne doit plus provoquer"
echo "BlockingIOError lorsqu'aucun événement n'est disponible."
echo ""
echo "Le hub relance automatiquement son patch local après le mécanisme"
echo "de mise à jour CGS afin de préparer le prochain lancement."
