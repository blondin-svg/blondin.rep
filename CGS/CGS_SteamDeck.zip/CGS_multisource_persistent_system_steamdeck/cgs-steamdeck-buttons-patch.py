#!/usr/bin/env python3
from pathlib import Path
import py_compile, shutil, sys, tempfile, time

MARKER = '# CONTROLES STRICTS STEAM DECK / CGS'
DEFAULT = Path('/userdata/system/cgs/app/clients/windows/__main__.py')

def apply(target: Path):
    if not target.exists():
        print(f'ERREUR: client Windows introuvable: {target}')
        return 2
    original = target.read_text(encoding='utf-8')
    work = original
    changed = False

    # Retire les alias A=X et B=Y=START dans les dialogues/menu standards.
    replacements = [
        ('if event.button in (BTN["A"], BTN["X"]):', 'if event.button == BTN["A"]:'),
        ('if items and event.button in (BTN["A"], BTN["X"]):', 'if items and event.button == BTN["A"]:'),
        ('if event.button in (BTN["A"], BTN["X"]) and missing:', 'if event.button == BTN["A"] and missing:'),
        ('if event.button in (BTN["B"], BTN["Y"], BTN["START"]):', 'if event.button == BTN["B"]:'),
        ('if event.button in (BTN["B"], BTN["START"]):', 'if event.button == BTN["B"]:'),
        ('elif event.button in (BTN["B"], BTN["START"]):', 'elif event.button == BTN["B"]:'),
    ]
    for old,new in replacements:
        if old in work:
            work = work.replace(old,new)
            changed = True

    # La fiche jeu : START doit ouvrir les actions comme A, et B seul revient.
    if 'def show_game(game):' in work and 'def is_admin_account():' in work:
        a,b = work.split('def show_game(game):',1)
        mid,c = b.split('def is_admin_account():',1)
        needle = '            if event.type == pygame.JOYBUTTONDOWN:\n                if event.button == BTN["A"]:\n'
        repl = '            if event.type == pygame.JOYBUTTONDOWN:\n                if event.button in (BTN["A"], BTN["START"]):\n'
        if needle in mid:
            mid = mid.replace(needle,repl,1)
            changed = True
        work = a + 'def show_game(game):' + mid + 'def is_admin_account():' + c

    # Ecran principal : applique réellement les rôles annoncés par la configuration.
    old_main = '''        if event.type == pygame.JOYBUTTONDOWN:\n            shown = [g for g in games if (not search_text or search_text.lower() in g["name"].lower() or search_text.lower() in g["path"].lower())]\n            if event.button == BTN["A"]:\n                if shown:\n                    show_game(shown[selected])\n            elif event.button in (BTN.get("LB", 4),):\n                selected = max(selected - 25, 0)\n            elif event.button in (BTN["RB"],):\n                selected = min(selected + 25, len(shown) - 1)\n            elif event.button in (BTN["Y"],):\n                if is_admin_account():\n                    if confirm_admin_bulk_sync():\n                        show_loading("Synchronisation globale des médias Windows...")\n                        bulk_stats, bulk_backup = run_admin_bulk_media_sync()\n                        show_admin_bulk_sync_result(bulk_stats, bulk_backup)\n                else:\n                    search_text = ""\n                    show_incomplete_only = False\n                    selected = 0\n                    offset = 0\n            elif event.button == BTN["B"]:\n                running = False\n'''
    new_main = '''        if event.type == pygame.JOYBUTTONDOWN:\n            shown = [g for g in games if (not search_text or search_text.lower() in g["name"].lower() or search_text.lower() in g["path"].lower())]\n            if event.button == BTN["A"]:\n                if shown:\n                    show_game(shown[selected])\n            elif event.button == BTN["X"]:\n                typed = manual_search_input(search_text)\n                if typed is not None:\n                    search_text = typed.strip()\n                    selected = 0\n                    offset = 0\n            elif event.button in (BTN.get("LB", 4),):\n                selected = max(selected - 25, 0)\n            elif event.button in (BTN["RB"],):\n                selected = min(selected + 25, len(shown) - 1)\n            elif event.button == BTN["Y"]:\n                show_incomplete_only = not show_incomplete_only\n                selected = 0\n                offset = 0\n            elif event.button == BTN["START"]:\n                if shown:\n                    show_game(shown[selected])\n            elif event.button == BTN["B"]:\n                running = False\n'''
    if new_main not in work:
        if old_main in work:
            work = work.replace(old_main,new_main,1)
            changed = True
        else:
            print('INCOMPATIBLE: bloc principal des boutons non reconnu.')
            return 20

    # Texte d'aide cohérent avec les boutons réels.
    old_help='draw_text("A/Entrée: sélectionner   B/Echap: quitter   ↑↓: naviguer   Y: incomplets   F: recherche   L/R: page", 45, 95, MUTED, font_small)'
    new_help='draw_text("A: fiche   B: quitter   X: recherche   Y: incomplets   START: fiche/actions   L/R: page", 45, 95, MUTED, font_small)'
    if old_help in work:
        work=work.replace(old_help,new_help)
        changed=True

    if MARKER not in work:
        anchor = 'DEFAULT_CONTROLLER = {\n'
        if anchor in work:
            work = work.replace(anchor, MARKER+'\n'+anchor,1)
            changed=True

    if not changed:
        print('Contrôles stricts déjà présents.')
        return 0

    with tempfile.NamedTemporaryFile('w',encoding='utf-8',suffix='.py',delete=False) as f:
        f.write(work); tmp=Path(f.name)
    try:
        py_compile.compile(str(tmp),doraise=True)
    except Exception as e:
        tmp.unlink(missing_ok=True)
        print(f'ERREUR: client patché invalide: {e}')
        return 30
    tmp.unlink(missing_ok=True)
    backup=target.with_name(target.name+f'.before-steamdeck-buttons-{int(time.time())}.bak')
    try:
        shutil.copy2(target,backup)
        target.write_text(work,encoding='utf-8')
        py_compile.compile(str(target),doraise=True)
    except Exception as e:
        if backup.exists(): shutil.copy2(backup,target)
        print(f'ERREUR: installation impossible: {e}')
        return 31
    print(f'OK: contrôles Steam Deck alignés sur la configuration. Sauvegarde: {backup}')
    return 0

if __name__=='__main__':
    target=Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT
    raise SystemExit(apply(target))
