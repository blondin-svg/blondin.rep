#!/usr/bin/env python3
from pathlib import Path
import py_compile
import shutil
import sys
import tempfile
import time
import re

MARKER = "# COMPATIBILITE STEAM DECK HUB (EVDEV DPAD)"
HOOK_MARKER = "# PATCH LOCAL STEAM DECK HUB (PERSISTANT)"
DEFAULT_TARGET = Path("/userdata/system/cgs/app/hub.py")

BUTTON_MARKER = "# CONTROLES BOUTONS STEAM DECK HUB"

BLOCK = r'''
# ============================================================
# COMPATIBILITE STEAM DECK HUB (EVDEV DPAD)
# ============================================================
# Sur Batocera, la croix du Steam Deck remonte comme BTN_DPAD_*
# (codes Linux 544..547) et pas forcément comme JOYHATMOTION SDL.
_DECK_HUB_DEVICE = None
_DECK_HUB_ECODES = None


def _deck_hub_detect():
 global _DECK_HUB_DEVICE, _DECK_HUB_ECODES
 try:
  from evdev import InputDevice, ecodes
 except Exception:
  return
 candidates=[]
 try:
  by_id=Path('/dev/input/by-id')
  if by_id.exists():
   candidates.extend(sorted(by_id.glob('*Steam*Deck*event-joystick')))
   candidates.extend(sorted(by_id.glob('*steam*deck*event-joystick')))
 except Exception:
  pass
 try:
  candidates.extend(sorted(Path('/dev/input').glob('event*')))
 except Exception:
  pass
 seen=set()
 for candidate in candidates:
  try:
   real=str(Path(candidate).resolve())
   if real in seen:continue
   seen.add(real)
   dev=InputDevice(real)
   if 'steam deck' not in (dev.name or '').lower():
    dev.close();continue
   caps=dev.capabilities(absinfo=False)
   keys=set(caps.get(ecodes.EV_KEY,[]))
   if not ({544,545,546,547} & keys):
    dev.close();continue
   os.set_blocking(dev.fd,False)
   _DECK_HUB_DEVICE=dev
   _DECK_HUB_ECODES=ecodes
   return
  except Exception:
   continue


def _deck_hub_poll_dpad():
 if _DECK_HUB_DEVICE is None or _DECK_HUB_ECODES is None:return False
 moved=False
 while True:
  try:
   ev=_DECK_HUB_DEVICE.read_one()
  except BlockingIOError:
   break
  except Exception:
   break
  if ev is None:break
  if ev.type==_DECK_HUB_ECODES.EV_KEY and ev.code in (544,545,546,547) and ev.value==1:
   moved=True
 return moved
'''

HOOK = r'''
# PATCH LOCAL STEAM DECK HUB (PERSISTANT)
# startup() peut remplacer hub.py pendant cette exécution. Le patch externe
# est donc relancé juste après pour préparer automatiquement le prochain démarrage.
_LOCAL_HUB_PATCH=Path('/userdata/system/cgs-steamdeck-hub-patch.py')
if _LOCAL_HUB_PATCH.exists():
 try:
  subprocess.run([sys.executable,str(_LOCAL_HUB_PATCH),str(Path(__file__).resolve())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
 except Exception:
  pass
'''

def apply(target: Path) -> int:
    if not target.exists():
        print(f"ERREUR: hub introuvable: {target}")
        return 2
    original=target.read_text(encoding='utf-8')
    work=original
    changed=False

    # Hook persistant juste après startup(...).
    # Compatible avec les variantes :
    #   startup(Path(...))
    #   UPDATE_NOTICE=startup(Path(...))
    if HOOK_MARKER not in work:
        startup_re = re.compile(
            r'(?m)^(?P<indent>[ \t]*)(?:(?:UPDATE_NOTICE|[A-Za-z_][A-Za-z0-9_]*)[ \t]*=[ \t]*)?'
            r'startup\(Path\(__file__\)\.resolve\(\)\.parent\)[ \t]*$'
        )
        m = startup_re.search(work)
        if not m:
            print('INCOMPATIBLE: appel startup() introuvable dans hub.py')
            return 20
        pos = m.end()
        work = work[:pos] + '\n' + HOOK.rstrip('\n') + work[pos:]
        changed=True

    # Fonctions evdev avant session_name().
    if MARKER not in work:
        anchor='def session_name():\n'
        if anchor not in work:
            print('INCOMPATIBLE: session_name() introuvable dans hub.py')
            return 21
        work=work.replace(anchor,BLOCK+'\n'+anchor,1)
        changed=True

    # Initialisation au démarrage du hub.
    # Le champ notice peut être vide (ancienne version) ou UPDATE_NOTICE
    # (versions récentes de CGS).
    if 'def main():' not in work:
        print('INCOMPATIBLE: main() introuvable dans hub.py')
        return 22
    main_part = work.split('def main():',1)[1]
    if '_deck_hub_detect()' not in main_part:
        init_re = re.compile(
            r'(?m)^(?P<indent>[ \t]+)display,canvas,sticks=start_display\(\);'
            r'selected=0;lastmove=0;notice=[^;\n]+;running=True;clock=pygame\.time\.Clock\(\)[ \t]*$'
        )
        m = init_re.search(work)
        if not m:
            print('INCOMPATIBLE: initialisation main() du hub non reconnue')
            return 22
        pos = m.end()
        indent = m.group('indent')
        work = work[:pos] + '\n' + indent + '_deck_hub_detect()' + work[pos:]
        changed=True

    # Boutons du contrôleur interne Steam Deck dans le hub.
    if BUTTON_MARKER not in work:
        old_buttons = '''   elif e.type==pygame.JOYBUTTONDOWN:
    if e.button in (0,2):launch=True
    elif e.button in (1,6,7,8):running=False
    elif e.button==3:disconnect();notice='Session déconnectée pour les deux systèmes.'
'''
        new_buttons = '''   elif e.type==pygame.JOYBUTTONDOWN:
    # CONTROLES BOUTONS STEAM DECK HUB
    is_deck_button=False
    try:
     joy_index=getattr(e,'joy',-1)
     if 0 <= joy_index < len(sticks):
      is_deck_button='steam deck' in (sticks[joy_index].get_name() or '').lower()
    except Exception:
     is_deck_button=False
    if is_deck_button:
     if e.button==3:launch=True
     elif e.button==4:running=False
     elif e.button==5:disconnect();notice='Session déconnectée pour les deux systèmes.'
    else:
     if e.button in (0,2):launch=True
     elif e.button in (1,6,7,8):running=False
     elif e.button==3:disconnect();notice='Session déconnectée pour les deux systèmes.'
'''
        if old_buttons not in work:
            print('INCOMPATIBLE: bloc boutons du hub non reconnu')
            return 24
        work=work.replace(old_buttons,new_buttons,1)
        changed=True

    # Lecture croix avant les événements pygame.
    if 'if _deck_hub_poll_dpad() and time.monotonic()-lastmove>.22:' not in work:
        anchor='  for e in pygame.event.get():\n'
        if anchor not in work:
            print('INCOMPATIBLE: boucle pygame du hub non reconnue')
            return 23
        inject=(
            '  if _deck_hub_poll_dpad() and time.monotonic()-lastmove>.22:\n'
            '   selected=1-selected;lastmove=time.monotonic()\n'
        )
        work=work.replace(anchor,inject+anchor,1)
        changed=True

    if not changed:
        print('Patch Steam Deck du hub déjà présent.')
        return 0

    with tempfile.NamedTemporaryFile('w',encoding='utf-8',suffix='.py',delete=False) as f:
        f.write(work); tmp=Path(f.name)
    try:
        py_compile.compile(str(tmp),doraise=True)
    except Exception as e:
        tmp.unlink(missing_ok=True)
        print(f'ERREUR: hub patché invalide: {e}')
        return 30
    tmp.unlink(missing_ok=True)

    backup=target.with_name(target.name+f'.before-steamdeck-patch-{int(time.time())}.bak')
    try:
        shutil.copy2(target,backup)
        target.write_text(work,encoding='utf-8')
        py_compile.compile(str(target),doraise=True)
    except Exception as e:
        if backup.exists():shutil.copy2(backup,target)
        print(f'ERREUR: installation hub impossible: {e}')
        return 31
    print(f'OK: hub Steam Deck patché. Sauvegarde: {backup}')
    return 0

if __name__=='__main__':
    target=Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT_TARGET
    raise SystemExit(apply(target))
